// ========================================================================= //
//
// gameoflife.js -- First rule of hacker club is you do talk about game of life
//
// Last modified: Thu Apr 24, 2014  11:52AM
// Maintainer:    Gokcehan Kara <gokcehankara@gmail.com>
// License:       This file is placed in the public domain.
//
// ========================================================================= //


var sideMargin = 22;
var topMargin = 85;
var bottomMargin = 85;

var rows;
var cols;

var width;
var height;

var w;
var h;

var ctx;
var canvas;
var board;


function initBoard() {
  var rowsSlider, colsSlider;

  rowsSlider = document.getElementById('rows');
  colsSlider = document.getElementById('cols');

  if (window.innerWidth > window.innerHeight) {
    rowsSlider.value *= 2;
    $('#rows').slider('refresh');
  }

  rows = +rowsSlider.value;
  cols = +colsSlider.value;

  board = new Array(rows);
  for (var i = 0; i < rows; i++) {
    board[i] = new Array(cols);
    for (var j = 0; j < cols; j++) {
      board[i][j] = false;
    }
  }

  // R-pentomino
  board[Math.floor(rows / 2) + 0][Math.floor(cols / 2) - 1] = true;
  board[Math.floor(rows / 2) + 1][Math.floor(cols / 2) - 1] = true;
  board[Math.floor(rows / 2) - 1][Math.floor(cols / 2) + 0] = true;
  board[Math.floor(rows / 2) + 0][Math.floor(cols / 2) + 0] = true;
  board[Math.floor(rows / 2) + 0][Math.floor(cols / 2) + 1] = true;
}

function resizeBoard() {
  var newBoard;
  var newRows, newCols;
  var minRows, minCols;
  var rowsSlider, colsSlider;

  rowsSlider = document.getElementById('rows');
  colsSlider = document.getElementById('cols');

  newRows = +rowsSlider.value;
  newCols = +colsSlider.value;

  newBoard = new Array(newRows);
  for (var i = 0; i < newRows; i++) {
    newBoard[i] = new Array(newCols);
    for (var j = 0; j < newCols; j++) {
      newBoard[i][j] = false;
    }
  }

  minRows = Math.min(rows, newRows);
  minCols = Math.min(cols, newCols);

  for (var i = 0; i < minRows; i++) {
    for (var j = 0; j < minCols; j++) {
      newBoard[i][j] = board[i][j];
    }
  }

  rows = newRows;
  cols = newCols;
  board = newBoard;
}

function resetBoard() {
  for (var i = 0; i < rows; i++) {
    for (var j = 0; j < cols; j++) {
      board[i][j] = false;
    }
  }
}

function markCell(i, j) {
  if ((0 <= i && i < rows) && (0 <= j && j < cols) && !board[i][j]) {
    board[i][j] = true;
    drawCell(i, j);
  }
}

function unmarkCell(i, j) {
  if ((0 <= i && i < rows) && (0 <= j && j < cols) && board[i][j]) {
    board[i][j] = false;
    drawCell(i, j);
  }
}

function countNeighbours(i, j) {
  neighbours = 0;
  if (board[(i - 1 + rows) % rows][(j - 1 + cols) % cols]) neighbours++;
  if (board[(i - 1 + rows) % rows][(j + 0 + cols) % cols]) neighbours++;
  if (board[(i - 1 + rows) % rows][(j + 1 + cols) % cols]) neighbours++;
  if (board[(i + 0 + rows) % rows][(j - 1 + cols) % cols]) neighbours++;
  if (board[(i + 0 + rows) % rows][(j + 1 + cols) % cols]) neighbours++;
  if (board[(i + 1 + rows) % rows][(j - 1 + cols) % cols]) neighbours++;
  if (board[(i + 1 + rows) % rows][(j + 0 + cols) % cols]) neighbours++;
  if (board[(i + 1 + rows) % rows][(j + 1 + cols) % cols]) neighbours++;
  return neighbours;
}

function tick() {
  var next = new Array(rows);
  for (var i = 0; i < rows; i++) {
    next[i] = new Array(cols);
    for (var j = 0; j < cols; j++) {
      switch (countNeighbours(i, j)) {
        case 2:
          next[i][j] = board[i][j];
          break;
        case 3:
          next[i][j] = true;
          break;
        default:
          next[i][j] = false;
          break;
      }
    }
  }
  board = next;
  drawBoard();
}

function drawCell(i, j) {
  ctx.clearRect(i * w, j * h, w, h);

  if (board[i][j]) {
    ctx.fillRect(i * w, j * h, w, h);
  } else {
    ctx.strokeRect(i * w, j * h, w, h);
  }
}

function drawBoard() {
  ctx.clearRect(0, 0, width, height);

  for (var i = 0; i < rows; i++) {
    for (var j = 0; j < cols; j++) {
      if (board[i][j]) {
        ctx.fillRect(i * w, j * h, w, h);
      } else {
        ctx.strokeRect(i * w, j * h, w, h);
      }
    }
  }
}

function resizeEvent(e) {
  width = window.innerWidth - (2 * sideMargin);
  height = window.innerHeight - (topMargin + bottomMargin);
  canvas.width = width;
  canvas.height = height;
  w = width / rows;
  h = height / cols;
  drawBoard();
}

function registerEvents() {
  var i, j;
  var erasing;
  var leftPressed, rightPressed;

  window.onresize = resizeEvent;

  document.oncontextmenu = function() { return false; };
  document.ondragstart = function() { return false; };

  $('#canvas').on('vmousedown', function(e) {
    i = Math.floor((e.clientX - sideMargin) / w);
    j = Math.floor((e.clientY - topMargin) / h);
    if (e.button === undefined || e.button === 0) {
      leftPressed = true;
      if (erasing) {
        unmarkCell(i, j);
      } else {
        markCell(i, j);
      }
    } else if (e.button === 2) {
      rightPressed = true;
      unmarkCell(i, j);
    }
  });

  $(document).on('vmouseup', function(e) {
    i = Math.floor((e.clientX - sideMargin) / w);
    j = Math.floor((e.clientY - topMargin) / h);
    if (e.button === undefined || e.button === 0) {
      leftPressed = false;
    } else if (e.button === 2) {
      rightPressed = false;
    }
  });

  $('#canvas').on('vmousemove', function(e) {
    i = Math.floor((e.clientX - sideMargin) / w);
    j = Math.floor((e.clientY - topMargin) / h);
    if (!erasing && leftPressed) {
      markCell(i, j);
    } else if (erasing && leftPressed) {
      unmarkCell(i, j);
    } else if (rightPressed) {
      unmarkCell(i, j);
    }

    // XXX: android chrome bug workaround
    // https://code.google.com/p/android/issues/detail?id=19827
    e.preventDefault();
  });

  eraseCheck = document.getElementById('erase-check');

  $('#erase-check').on('change', function(e) {
    erasing = eraseCheck.checked;
  });
}

function registerButtons() {
  var fps;
  var playing;
  var playCheck;
  var fpsSlider, rowsSlider, colsSlider;

  fpsSlider = document.getElementById('fps');
  fps = fpsSlider.value;

  $('#fps').on('change', function(e, i) {
    fps = fpsSlider.value;
    if (playing) {
      clearInterval(ticking);
      ticking = setInterval(tick, 1000 / fps);
    }
  });

  $('#rows').on('change', function(e, i) {
    resizeBoard();
    resizeEvent();
  });

  $('#cols').on('change', function(e, i) {
    resizeBoard();
    resizeEvent();
  });

  $('#tick').on('click', function(e) {
    tick();
  });

  $('#reset').on('click', function(e) {
    resetBoard();
    drawBoard();
  });

  playCheck = document.getElementById('play-check');

  $('#play-check').on('change', function(e) {
    if (playCheck.checked && !playing) {
      playing = true;
      ticking = setInterval(tick, 1000 / fps);
    } else if (!playCheck.checked && playing) {
      playing = false;
      clearInterval(ticking);
    }
  });
}

function init() {
  canvas = document.getElementById('canvas');
  if (!canvas.getContext) return;
  ctx = canvas.getContext('2d');

  $(document).ready(function() {
    initBoard();
    registerEvents();
    registerButtons();
    resizeEvent();
  });
}
